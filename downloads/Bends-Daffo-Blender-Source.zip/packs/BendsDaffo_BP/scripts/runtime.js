import { CLIPS } from "./clips.js";

/** @typedef {import('@minecraft/server').Entity} Entity */
/** @typedef {import('@minecraft/server').Player} Player */
/** @typedef {{entity: Entity, clip: string, until: number, priority: number, lastAttack: number, combo: number, knockdownUntil: number, seen: number, ground: boolean, vertical: number}} Actor */
/** @typedef {{wood: boolean, axe: boolean, dimension: string}} Mining */

export const HUMANOIDS = new Set([
  "minecraft:player", "minecraft:zombie", "minecraft:husk", "minecraft:drowned",
]);

/** @param {string} id */
export function isWood(id) {
  return /(?:_log|_wood|_stem|_hyphae)$/.test(id) || /^(?:minecraft:)?(?:stripped_)?bamboo_block$/.test(id);
}

/**
 * Event-driven attacks/reactions; bounded player locomotion polling.
 * No teleports, extra damage, input locks, potion effects or AI replacements.
 * @param {{world: import('@minecraft/server').World, system: import('@minecraft/server').System, random?: () => number, log?: (message: string) => void}} deps
 */
export function createRuntime({ world, system, random = Math.random, log = console.warn }) {
  /** @type {Map<string, Actor>} */
  const actors = new Map();
  /** @type {Map<string, Mining>} */
  const mining = new Map();
  const usingItem = new Set();
  /** @type {Array<() => void>} */
  const unsubscribe = [];
  const config = { enabled: true, knockdownChance: 0.22 };
  let lastWarning = -1000;

  /** @param {unknown} error */
  function warn(error) {
    if (system.currentTick - lastWarning >= 200) {
      log(`[Bends-Daffo] ${String(error)}`);
      lastWarning = system.currentTick;
    }
  }

  /** @param {Entity} entity */
  function actor(entity) {
    let a = actors.get(entity.id);
    if (!a) {
      a = { entity, clip: "", until: 0, priority: 0, lastAttack: -1000, combo: 0,
        knockdownUntil: 0, seen: system.currentTick, ground: entity.isOnGround,
        vertical: entity.getVelocity().y };
      actors.set(entity.id, a);
    }
    a.entity = entity;
    a.seen = system.currentTick;
    return a;
  }

  /** @param {Entity} entity */
  function alive(entity) {
    if (!entity.isValid || !HUMANOIDS.has(entity.typeId)) return false;
    if (entity.getComponent("minecraft:is_baby")) return false;
    const health = entity.getComponent("minecraft:health");
    return !health || health.currentValue > 0;
  }

  /**
   * A single shared controller replaces the preceding full-body clip.
   * Omitting options.players broadcasts to viewers instead of just the attacker.
   * A separate arm controller provides a small first-person overlay.
   * @param {Entity} entity @param {string} clip @param {number} priority
   */
  function play(entity, clip, priority) {
    if (!config.enabled || !alive(entity) || !CLIPS[clip]) return false;
    const a = actor(entity);
    const tick = system.currentTick;
    if (tick < a.until && a.priority > priority) return false;
    const duration = CLIPS[clip];
    // Interrupted locomotion stops via its server action controller replacement.
    entity.playAnimation(`animation.bends_daffo.${clip}`, {
      controller: "bends_daffo_pose",
      nextState: "default",
      blendOutTime: priority === 3 ? 0.10 : 0.14,
      stopExpression: `query.anim_time >= ${duration}`,
    });
    if (entity.typeId === "minecraft:player" && ["punch_right", "punch_left", "strike", "chop", "mine", "hurt_left", "hurt_right"].includes(clip)) {
      entity.playAnimation(`animation.bends_daffo.fp_${clip}`, {
        controller: "bends_daffo_arms", nextState: "default", blendOutTime: 0.12,
        stopExpression: `query.anim_time >= ${duration}`,
      });
    }
    a.clip = clip;
    a.until = tick + Math.ceil(duration * 20);
    a.priority = priority;
    return true;
  }

  /** @param {Entity} entity @param {Actor} a */
  function release(entity, a) {
    if (a.clip === "release" || !a.clip) return;
    entity.playAnimation("animation.bends_daffo.release", {
      controller: "bends_daffo_pose", nextState: "default", blendOutTime: 0.12,
      stopExpression: "query.anim_time >= 0.1",
    });
    a.clip = "release"; a.until = 0; a.priority = 0;
  }

  /** @param {Entity} entity @param {string | undefined} heldId */
  function attack(entity, heldId) {
    if (!config.enabled || !alive(entity)) return;
    const a = actor(entity);
    // Swing and hit events can describe the same hit. Avoid starting it twice.
    if (system.currentTick - a.lastAttack < 4) return;
    const weapon = heldId ?? entity.getComponent("minecraft:equippable")?.getEquipment(/** @type {import('@minecraft/server').EquipmentSlot} */ ("Mainhand"))?.typeId;
    const armed = !!weapon && /_(?:sword|axe)$|:(?:mace|trident)$/.test(weapon);
    const clip = armed ? "strike" : (a.combo % 2 === 0 ? "punch_right" : "punch_left");
    if (play(entity, clip, 2)) {
      a.lastAttack = system.currentTick;
      a.combo++;
    }
  }

  /** @param {Player} player @param {string} blockId @param {string | undefined} heldId */
  function beginMining(player, blockId, heldId) {
    if (!config.enabled) return;
    const m = { wood: isWood(blockId), axe: !!heldId?.endsWith("_axe"), dimension: player.dimension.id };
    mining.set(player.id, m);
    play(player, m.wood && m.axe ? "chop" : "mine", 2);
  }

  /** @param {import('@minecraft/server').EntityHurtAfterEvent} event */
  function hurt(event) {
    const victim = event.hurtEntity;
    if (!config.enabled || !alive(victim) || event.damage <= 0) return;
    // Environmental damage/projectiles are not a melee reaction.
    if (event.damageSource.cause !== "entityAttack" || !event.damageSource.damagingEntity) return;
    const a = actor(victim);
    if (a.clip === "knockdown" && system.currentTick < a.until) return;
    const canFall = system.currentTick >= a.knockdownUntil && victim.isOnGround &&
      !victim.isInWater && !victim.isClimbing && !victim.getComponent("minecraft:riding") &&
      !(victim.typeId === "minecraft:player" && (/** @type {Player} */ (victim).isFlying || /** @type {Player} */ (victim).isGliding));
    if (canFall && random() < config.knockdownChance) {
      if (play(victim, "knockdown", 3)) a.knockdownUntil = system.currentTick + 100;
    } else {
      play(victim, random() < 0.5 ? "hurt_left" : "hurt_right", 3);
    }
  }

  function step() {
    if (!config.enabled) return;
    const online = new Set();
    for (const player of world.getAllPlayers()) {
      online.add(player.id);
      try {
        if (!alive(player)) { actors.delete(player.id); mining.delete(player.id); continue; }
        const a = actor(player);
        const ground = player.isOnGround;
        const velocity = player.getVelocity();
        const speed = Math.hypot(velocity.x, velocity.z);
        const blocked = player.isFlying || player.isGliding || player.isClimbing ||
          player.isSleeping || !!player.getComponent("minecraft:riding") ||
          player.getGameMode() === "Spectator";
        const justJumped = a.ground && !ground && velocity.y > 0.08;
        const justLanded = !a.ground && ground && a.vertical < -0.08;
        a.ground = ground;
        a.vertical = velocity.y;
        if (blocked) { mining.delete(player.id); release(player, a); continue; }
        if (system.currentTick < a.until && a.priority >= 2) continue;
        let m = mining.get(player.id);
        if (m && m.dimension !== player.dimension.id) { mining.delete(player.id); m = undefined; }
        let clip = "";
        if (m && ground) clip = m.wood && m.axe ? "chop" : "mine";
        else if (player.isSwimming) clip = "swim";
        else if (player.isInWater && !ground) clip = "tread_water";
        else if (justJumped) clip = "jump";
        else if (justLanded) clip = "land";
        else if (!ground && velocity.y < -0.08) clip = "fall";
        else if (ground && speed > 0.018 && !player.isSneaking && !usingItem.has(player.id)) clip = player.isSprinting ? "run" : "walk";
        else if (ground && !player.isSneaking && !usingItem.has(player.id)) clip = "idle";
        if (!clip) { if (a.priority <= 1 || system.currentTick >= a.until) release(player, a); continue; }
        // Don't cut off takeoff or landing with a walk/idle sample on the next tick.
        if (["jump", "land"].includes(a.clip) && system.currentTick < a.until && ["walk", "run", "idle", "fall"].includes(clip)) continue;
        if (clip !== a.clip || system.currentTick >= a.until) play(player, clip, m ? 2 : 1);
      } catch (error) { warn(error); }
    }
    if (system.currentTick % 100 === 0) {
      for (const [id, a] of actors) {
        if (!a.entity.isValid || (a.entity.typeId === "minecraft:player" && !online.has(id)) || system.currentTick - a.seen > 400) {
          actors.delete(id); mining.delete(id); usingItem.delete(id);
        }
      }
    }
  }

  /** @template T @param {{subscribe: (cb: (e: T) => void) => unknown, unsubscribe: (cb: (e: T) => void) => void}} signal @param {(e: T) => void} callback */
  function on(signal, callback) {
    /** @param {T} event */
    const guarded = event => { try { callback(event); } catch (error) { warn(error); } };
    signal.subscribe(guarded);
    unsubscribe.push(() => signal.unsubscribe(guarded));
  }

  on(world.afterEvents.playerSwingStart, e => {
    if (e.swingSource === "Attack") attack(e.player, e.heldItemStack?.typeId);
  });
  on(world.afterEvents.entityHitEntity, e => attack(e.damagingEntity, undefined));
  on(world.afterEvents.entityHurt, hurt);
  on(world.afterEvents.playerStartBreakingBlock, e => beginMining(e.player, e.blockPermutation.type.id, e.heldItemStack?.typeId));
  on(world.afterEvents.playerCancelBreakingBlock, e => mining.delete(e.player.id));
  on(world.afterEvents.playerBreakBlock, e => mining.delete(e.player.id));
  on(world.afterEvents.entityRemove, e => { actors.delete(e.removedEntityId); mining.delete(e.removedEntityId); usingItem.delete(e.removedEntityId); });
  on(world.afterEvents.playerSpawn, e => { actors.delete(e.player.id); mining.delete(e.player.id); usingItem.delete(e.player.id); });
  on(world.afterEvents.itemStartUse, e => usingItem.add(e.source.id));
  on(world.afterEvents.itemStopUse, e => usingItem.delete(e.source.id));
  on(world.afterEvents.itemCompleteUse, e => usingItem.delete(e.source.id));
  on(world.afterEvents.itemReleaseUse, e => usingItem.delete(e.source.id));

  on(system.afterEvents.scriptEventReceive, e => {
    if (!e.id.startsWith("bends_daffo:")) return;
    const sender = e.sourceEntity?.typeId === "minecraft:player" ? /** @type {Player} */ (e.sourceEntity) : undefined;
    /** @param {string} message */
    const reply = message => sender ? sender.sendMessage(`§b[Bends-Daffo]§r ${message}`) : log(`[Bends-Daffo] ${message}`);
    if (e.id === "bends_daffo:chance") {
      const n = Number(e.message.trim());
      if (e.message.trim() === "" || !Number.isFinite(n) || n < 0 || n > 1) return reply("Peluang harus angka 0 sampai 1, misalnya 0.22.");
      config.knockdownChance = n;
      world.setDynamicProperty("bends_daffo:chance", n);
      reply(`Peluang jatuh: ${Math.round(n * 100)}%.`);
    } else if (e.id === "bends_daffo:enabled") {
      if (!["on", "off"].includes(e.message.trim())) return reply("Gunakan on atau off.");
      config.enabled = e.message.trim() === "on";
      world.setDynamicProperty("bends_daffo:enabled", config.enabled);
      actors.clear(); mining.clear(); usingItem.clear();
      reply(config.enabled ? "Animasi server aktif." : "Animasi server berhenti setelah klip yang sedang diputar selesai.");
    } else if (e.id === "bends_daffo:demo") {
      const clip = e.message.trim();
      if (!sender || !CLIPS[clip]) return reply(`Demo: ${Object.keys(CLIPS).join(", ")}. Jalankan sebagai pemain.`);
      play(sender, clip, 3);
    } else if (e.id === "bends_daffo:status") {
      reply(`v1.0.0 | ${config.enabled ? "aktif" : "nonaktif"} | jatuh ${Math.round(config.knockdownChance * 100)}% | ${actors.size} aktor terlacak.`);
    }
  });

  // World properties are unavailable during module early execution.
  const loadId = system.run(() => {
    try {
      const chance = world.getDynamicProperty("bends_daffo:chance");
      const enabled = world.getDynamicProperty("bends_daffo:enabled");
      if (typeof chance === "number" && chance >= 0 && chance <= 1) config.knockdownChance = chance;
      if (typeof enabled === "boolean") config.enabled = enabled;
      log("[Bends-Daffo] v1.0.0 loaded — Bedrock 26.50 / stable Script API 2.10.0.");
    } catch (error) { warn(error); }
  });
  const intervalId = system.runInterval(() => { try { step(); } catch (error) { warn(error); } }, 2);
  return { config, stop() { system.clearRun(intervalId); system.clearRun(loadId); unsubscribe.forEach(fn => fn()); actors.clear(); mining.clear(); usingItem.clear(); } };
}
