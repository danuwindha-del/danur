import { world, system } from "@minecraft/server";
import { createRuntime } from "./runtime.js";

// Stable Script API only. Every animation is requested by the world host.
createRuntime({ world, system });
