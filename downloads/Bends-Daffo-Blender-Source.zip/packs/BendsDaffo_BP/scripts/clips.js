// Generated from Blender actions. Re-export after editing motion.
/** @type {Readonly<Record<string, number>>} */
export const CLIPS = Object.freeze({
  "chop": 0.9,
  "fall": 0.8,
  "hurt_left": 0.5,
  "hurt_right": 0.5,
  "idle": 2.0,
  "jump": 0.4,
  "knockdown": 2.6,
  "land": 0.3,
  "mine": 0.6,
  "punch_left": 0.5,
  "punch_right": 0.5,
  "release": 0.1,
  "run": 0.6,
  "strike": 0.7,
  "swim": 1.2,
  "tread_water": 1.2,
  "walk": 1.0
});
