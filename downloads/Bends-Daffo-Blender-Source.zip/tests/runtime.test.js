import test from "node:test";
import assert from "node:assert/strict";
import { createRuntime, isWood } from "../packs/BendsDaffo_BP/scripts/runtime.js";

class Signal {
  callbacks = new Set();
  subscribe(cb) { this.callbacks.add(cb); return cb; }
  unsubscribe(cb) { this.callbacks.delete(cb); }
  emit(event) { for (const cb of this.callbacks) cb(event); }
}

function fixture(random = () => 0.9, properties = new Map()) {
  const events = ["playerSwingStart", "entityHitEntity", "entityHurt", "playerStartBreakingBlock",
    "playerCancelBreakingBlock", "playerBreakBlock", "entityRemove", "playerSpawn",
    "itemStartUse", "itemStopUse", "itemCompleteUse", "itemReleaseUse"];
  const afterEvents = Object.fromEntries(events.map(name => [name, new Signal()]));
  const queued = new Map();
  const intervals = new Map();
  let nextId = 0;
  let initialized = false;
  const logs = [];
  const players = [];
  const system = {
    currentTick: 0,
    afterEvents: { scriptEventReceive: new Signal() },
    run(fn) { const id = nextId++; queued.set(id, fn); return id; },
    runInterval(fn, period) { const id = nextId++; intervals.set(id, { fn, period }); return id; },
    clearRun(id) { queued.delete(id); intervals.delete(id); },
  };
  const world = {
    afterEvents,
    getAllPlayers: () => players,
    getDynamicProperty(key) { assert.ok(initialized, "World properties cannot be read during early execution"); return properties.get(key); },
    setDynamicProperty(key, value) { properties.set(key, value); },
  };
  const runtime = createRuntime({ world, system, random, log: message => logs.push(message) });
  function advance(n = 2) {
    for (let i = 0; i < n; i++) {
      system.currentTick++;
      initialized = true;
      for (const [id, fn] of queued) { queued.delete(id); fn(); }
      for (const { fn, period } of intervals.values()) if (system.currentTick % period === 0) fn();
    }
  }
  function entity(id, typeId = "minecraft:player") {
    const e = {
      id, typeId, isValid: true, isOnGround: true, isInWater: false, isSwimming: false,
      isFlying: false, isGliding: false, isClimbing: false, isSleeping: false,
      isSneaking: false, isSprinting: false, baby: false, riding: false,
      dimension: { id: "minecraft:overworld" },
      health: 20, weapon: undefined, velocity: { x: 0, y: 0, z: 0 },
      animations: [], messages: [],
      getVelocity() { return this.velocity; },
      getGameMode() { return "Survival"; },
      getComponent(id) {
        if (id === "minecraft:health") return { currentValue: this.health };
        if (id === "minecraft:equippable") return { getEquipment: () => this.weapon && { typeId: this.weapon } };
        if (id === "minecraft:riding") return this.riding ? {} : undefined;
        if (id === "minecraft:is_baby") return this.baby ? {} : undefined;
        return undefined;
      },
      playAnimation(name, options) { if (!this.isValid) throw Error("InvalidEntityError"); this.animations.push({ name, options, tick: system.currentTick }); },
      sendMessage(message) { this.messages.push(message); },
    };
    if (typeId === "minecraft:player") players.push(e);
    return e;
  }
  const swing = (player, heldItemStack) => afterEvents.playerSwingStart.emit({ player, heldItemStack, swingSource: "Attack" });
  const hurt = (victim, attacker, cause = "entityAttack", damage = 2) => afterEvents.entityHurt.emit({ hurtEntity: victim, damage, damageSource: { damagingEntity: attacker, cause } });
  const command = (sourceEntity, name, message = "") => system.afterEvents.scriptEventReceive.emit({ id: "bends_daffo:" + name, message, sourceEntity });
  const clip = e => e.animations.filter(a => a.options.controller === "bends_daffo_pose").at(-1)?.name.replace("animation.bends_daffo.", "");
  return { runtime, system, world, players, logs, properties, advance, entity, swing, hurt, command, clip };
}

test("attacking alternates hands, deduplicates swing+hit, and broadcasts both combatants", () => {
  const f = fixture();
  const a = f.entity("a"), b = f.entity("b");
  f.advance();
  f.swing(a);
  f.world.afterEvents.entityHitEntity.emit({ damagingEntity: a, hitEntity: b });
  f.hurt(b, a);
  assert.equal(a.animations.filter(v => /punch/.test(v.name) && !/fp_/.test(v.name)).length, 1);
  assert.equal(f.clip(a), "punch_right");
  assert.equal(f.clip(b), "hurt_right");
  for (const e of [a, b]) for (const animation of e.animations) {
    assert.equal(Object.hasOwn(animation.options, "players"), false, "no attacker-only audience");
    assert.ok(animation.options.stopExpression);
  }
  f.advance(12);
  f.swing(a);
  assert.equal(f.clip(a), "punch_left");
  f.runtime.stop();
});

test("server-driven zombie reaction falls, stands up clip completes, and cooldown prevents repeated falls", () => {
  const f = fixture(() => 0);
  const a = f.entity("a"), z = f.entity("z", "minecraft:zombie");
  f.advance();
  f.hurt(z, a);
  assert.equal(f.clip(z), "knockdown");
  assert.match(z.animations.at(-1).options.stopExpression, /2.6/);
  f.advance(12);
  f.hurt(z, a);
  assert.equal(z.animations.length, 1, "do not restart the stand-up sequence mid-fall");
  f.advance(42);
  f.hurt(z, a);
  assert.equal(f.clip(z), "hurt_left", "five-second victim cooldown");
  f.advance(50);
  f.hurt(z, a);
  assert.equal(f.clip(z), "knockdown");
  assert.equal(z.health, 20, "animation must not apply additional damage");
});

test("player can be knocked down too; victim reaction overrides their attack", () => {
  const f = fixture(() => 0);
  const a = f.entity("a"), b = f.entity("b");
  f.advance(); f.swing(b); f.hurt(b, a); f.swing(b);
  assert.equal(f.clip(b), "knockdown");
  f.advance(10);
  assert.equal(f.clip(b), "knockdown", "locomotion must not override the reaction");
});

test("weapon hit chooses strike; mobs can animate their outgoing hit", () => {
  const f = fixture();
  const p = f.entity("p"), z = f.entity("z", "minecraft:zombie");
  p.weapon = "minecraft:iron_sword";
  f.advance(); f.swing(p);
  assert.equal(f.clip(p), "strike");
  f.world.afterEvents.entityHitEntity.emit({ damagingEntity: z, hitEntity: p });
  assert.equal(f.clip(z), "punch_right");
});

test("non-melee, fatal hits, baby zombies, and unsupported animals retain vanilla reactions", () => {
  const f = fixture(() => 0);
  const p = f.entity("p"), z = f.entity("z", "minecraft:zombie"), cow = f.entity("c", "minecraft:cow");
  f.advance();
  for (const cause of ["fire", "fall", "projectile", "drowning"]) f.hurt(z, p, cause);
  f.hurt(z, p, "entityAttack", 0);
  assert.equal(z.animations.length, 0);
  z.health = 0; f.hurt(z, p); assert.equal(z.animations.length, 0);
  z.health = 20; z.baby = true; f.hurt(z, p); assert.equal(z.animations.length, 0);
  f.hurt(cow, p); assert.equal(cow.animations.length, 0);
});

test("swimming victims flinch without falling", () => {
  const f = fixture(() => 0);
  const p = f.entity("p"), z = f.entity("z", "minecraft:drowned");
  z.isOnGround = false; z.isInWater = true;
  f.advance(); f.hurt(z, p);
  assert.equal(f.clip(z), "hurt_left");
});

test("log chopping repeats while mining and stops on cancellation or completed break", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  const event = { player: p, blockPermutation: { type: { id: "minecraft:oak_log" } }, heldItemStack: { typeId: "minecraft:iron_axe" } };
  f.world.afterEvents.playerStartBreakingBlock.emit(event);
  assert.equal(f.clip(p), "chop");
  f.advance(20);
  assert.equal(p.animations.filter(a => a.name === "animation.bends_daffo.chop").length, 2);
  f.world.afterEvents.playerCancelBreakingBlock.emit({ player: p });
  f.advance(20); assert.equal(f.clip(p), "idle");
  f.world.afterEvents.playerStartBreakingBlock.emit(event);
  f.world.afterEvents.playerBreakBlock.emit({ player: p });
  f.advance(20); assert.equal(f.clip(p), "idle");
});

test("bare-hand mining, non-wood blocks and logs are distinguished", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  f.world.afterEvents.playerStartBreakingBlock.emit({ player: p, blockPermutation: { type: { id: "minecraft:oak_log" } } });
  assert.equal(f.clip(p), "mine");
  f.world.afterEvents.playerStartBreakingBlock.emit({ player: p, blockPermutation: { type: { id: "minecraft:stone" } }, heldItemStack: { typeId: "minecraft:diamond_axe" } });
  assert.equal(f.clip(p), "mine");
  for (const id of ["oak_log", "stripped_oak_wood", "crimson_stem", "warped_hyphae", "bamboo_block", "stripped_bamboo_block"]) assert.equal(isWood("minecraft:" + id), true);
  assert.equal(isWood("minecraft:oak_planks"), false);
});

test("dimension change clears active mining and restores locomotion priority", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  f.world.afterEvents.playerStartBreakingBlock.emit({ player: p, blockPermutation: { type: { id: "minecraft:oak_log" } }, heldItemStack: { typeId: "minecraft:iron_axe" } });
  p.dimension.id = "minecraft:nether";
  f.advance(20); assert.equal(f.clip(p), "idle");
  p.isOnGround = false; p.velocity.y = .4;
  f.advance(); assert.equal(f.clip(p), "jump", "stale mining must not block movement in a new dimension");
});

test("jump, falling, landing, walking and sprinting select distinct authored clips", () => {
  const f = fixture(); const p = f.entity("p");
  p.velocity.x = .08; f.advance(); assert.equal(f.clip(p), "walk");
  p.isSprinting = true; f.advance(); assert.equal(f.clip(p), "run");
  p.isOnGround = false; p.velocity.y = .4; f.advance(); assert.equal(f.clip(p), "jump");
  p.velocity.y = -.2; f.advance(10); assert.equal(f.clip(p), "fall");
  p.isOnGround = true; p.velocity.y = 0; f.advance(); assert.equal(f.clip(p), "land");
  f.advance(8); assert.equal(f.clip(p), "run");
});

test("walking off a ledge is falling, not jumping; swimming and treading are separate", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  p.isOnGround = false; p.velocity.y = -.2; f.advance(); assert.equal(f.clip(p), "fall");
  p.isSwimming = true; p.isInWater = true; f.advance(); assert.equal(f.clip(p), "swim");
  p.isSwimming = false; f.advance(); assert.equal(f.clip(p), "tread_water");
});

test("sneaking, riding, flying, sleeping, climbing and item use release custom locomotion", () => {
  for (const property of ["isSneaking", "riding", "isFlying", "isSleeping", "isClimbing", "isGliding", "using"]) {
    const f = fixture(); const p = f.entity("p"); f.advance(); assert.equal(f.clip(p), "idle");
    if (property === "using") f.world.afterEvents.itemStartUse.emit({ source: p });
    else p[property] = true;
    f.advance(); assert.equal(f.clip(p), "release", property);
    const n = p.animations.length;
    f.advance(4); assert.equal(p.animations.length, n, "release once, not every poll");
  }
});

test("settings are bounded, saved on the host and restored without early world access", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  f.command(p, "chance", "1.1"); assert.equal(f.runtime.config.knockdownChance, .22);
  f.command(p, "chance", ""); assert.equal(f.runtime.config.knockdownChance, .22);
  f.command(p, "chance", "NaN"); assert.equal(f.runtime.config.knockdownChance, .22);
  f.command(p, "chance", "0.5"); assert.equal(f.properties.get("bends_daffo:chance"), .5);
  f.command(p, "enabled", "off"); assert.equal(f.properties.get("bends_daffo:enabled"), false);
  const n = p.animations.length; f.advance(20); f.swing(p); assert.equal(p.animations.length, n);
  const reboot = fixture(() => 0, f.properties); reboot.advance();
  assert.deepEqual(reboot.runtime.config, { enabled: false, knockdownChance: .5 });
});

test("demo reliably exercises knockdown without requiring random chance or damage", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  f.command(p, "demo", "knockdown"); assert.equal(f.clip(p), "knockdown");
  assert.equal(p.health, 20);
  f.command(p, "demo", "not_an_animation"); assert.match(p.messages.at(-1), /Demo:/);
});

test("despawn removes actors, and stop unsubscribes and cancels timers", () => {
  const f = fixture(); const p = f.entity("p"), z = f.entity("z", "minecraft:husk");
  f.advance(); f.hurt(z, p); f.command(p, "status"); assert.match(p.messages.at(-1), /2 aktor/);
  f.world.afterEvents.entityRemove.emit({ removedEntityId: z.id });
  f.command(p, "status"); assert.match(p.messages.at(-1), /1 aktor/);
  f.runtime.stop(); const n = p.animations.length; f.advance(20); f.swing(p); assert.equal(p.animations.length, n);
  assert.equal(f.world.afterEvents.entityHurt.callbacks.size, 0);
});

test("unexpected engine errors are reported with bounded log volume", () => {
  const f = fixture(); const p = f.entity("p"); f.advance();
  p.playAnimation = () => { throw Error("engine rejected animation"); };
  f.swing(p); f.swing(p); f.advance(4); f.swing(p);
  assert.equal(f.logs.filter(m => m.includes("engine rejected")).length, 1);
});
