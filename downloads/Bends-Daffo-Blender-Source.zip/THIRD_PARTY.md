# Sumber pihak ketiga

Definisi client entity, dasar geometri, dan render controller berasal dari
[Mojang/bedrock-samples](https://github.com/Mojang/bedrock-samples), tag
`v1.26.50.4`, commit `46ba6ea985fb5a92d79a9419198f10dda14c199d`.
Daftar file ada di `vendor/mojang/SOURCE.json`.

Pemberitahuan asli: **(c) Mojang AB. All rights reserved.** File tersebut tunduk
pada [Minecraft EULA](https://www.minecraft.net/en-us/eula), bukan lisensi MIT
proyek ini. Definisi yang dipakai dipertahankan atau diturunkan untuk
kompatibilitas add-on; aset game berbayar dan executable Minecraft tidak disertakan.

Rig preview, klip animasi, exporter Blender, skrip runtime, dan ikon BD merupakan
aset asli proyek. Tidak ada aset, motion capture, atau animasi GTA yang disalin.

API dibangun menggunakan deklarasi resmi `@minecraft/server` versi `2.10.0`.
Minecraft sendiri menyediakan modul tersebut saat add-on dijalankan;
`node_modules` tidak disertakan dalam paket.
