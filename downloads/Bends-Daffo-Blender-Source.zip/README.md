# Bends-Daffo — Bedrock 26.50

Add-on animasi gerak dan pertarungan, dibuat memakai **Blender 4.3.2** dan
**Minecraft stable Script API 2.10.0**. Paket `.mcaddon`, source `.blend`, rig,
dan exporter disediakan. Model tetap bergaya kotak Minecraft; gerakan memakai
anticipation, putaran tubuh, follow-through, tekukan siku/lutut, dan recovery.

**Status:** paket sudah dibangun dan lolos pemeriksaan otomatis di lingkungan
pengembangan. Minecraft client/server belum dijalankan di lingkungan ini.
Impor, content log, tampilan skin/armor, dan multiplayer dua perangkat harus
lulus [uji dalam game](docs/UJI_DALAM_GAME.md) sebelum dinyatakan rilis teruji.
Render Blender adalah preview aset, bukan screenshot Minecraft.

## File untuk digunakan

- `dist/Bends-Daffo-1.0.0-Bedrock-26.50.mcaddon`: behavior + resource pack.
- `dist/Bends-Daffo-Blender-Source.zip`: rig, `.blend`, skrip, dan panduan.
- `blender/Bends-Daffo.blend`: 24 Action Blender yang bisa diedit.
- `dist/SHA256.json`: checksum berkas hasil build.
- [Cara memasang](docs/PASANG.md).

## Fitur

| Gerakan | Implementasi |
| --- | --- |
| Memukul tangan kosong | Jab kanan/kiri bergantian, putaran torso dan recovery |
| Senjata | Swing lebih berat untuk sword, axe, mace, dan trident |
| Menebang kayu | Chop berulang saat menambang log/wood/stem/hyphae/bamboo block memakai axe |
| Menambang biasa | Gerakan mine; berhenti setelah blok pecah atau penambangan dibatalkan |
| Lompat | Takeoff, pose turun, dan penyerapan benturan saat mendarat |
| Renang | Siklus stroke dan tendangan; tread-water saat berada di air |
| Jalan/lari/diam | Ayunan anggota badan dan gerak napas ringan |
| Terkena pukulan | Flinch kiri/kanan untuk pemain, zombie, husk, drowned dewasa |
| Jatuh lalu bangkit | Peluang default 22% saat melee di darat, durasi 2,6 detik, cooldown 5 detik |
| Multiplayer | Host memicu `Entity.playAnimation`; tidak membatasi audience ke satu pemain |
| Kamera pertama | Overlay lengan kecil untuk pukulan, mine/chop, dan flinch |

Tidak ada damage tambahan, penguncian input, teleportasi, penggantian AI,
efek slowness, atau perubahan hitbox. Jatuh merupakan animasi visual; pemain
atau mob masih dapat bergerak. Ini bukan ragdoll fisik seperti mesin GTA.
Pukulan proyektil dan damage lingkungan tidak memicu jatuh melee.

## Skin dan kompatibilitas

Pada pengaturan resource pack, pilih subpack melalui ikon roda gigi:

- **Sendi siku/lutut — skin klasik Steve**: geometri 64×64 dengan sendi tambahan.
  Direkomendasikan untuk melihat hasil penuh. Custom classic skin dengan lengan
  Steve menjadi target; tampilan skin personal tetap perlu uji dalam game.
- **Skin kompatibel — gerak dasar, sendi bawaan**: mempertahankan geometri
  bawaan/skin. Gerak torso/anggota badan tersedia, tetapi siku dan lutut tambahan
  hanya bekerja pada mode sendi aktif. Pilih ini untuk Alex/slim, Persona,
  Marketplace, atau jika skin berubah/tidak cocok.

Mode sendi aktif berlaku untuk resource pack dunia sehingga bentuk lengan
Steve dipakai untuk seluruh pemain. Armor dan attachable vanilla dipertahankan,
tetapi mesh armor belum dibagi menjadi siku/lutut dan dapat beririsan pada pose
ekstrem. Baby zombie mempertahankan animasi bawaan. Mob selain empat tipe di
atas tidak diubah. Resource pack lain yang mengganti player/entity/render
controller yang sama bisa bentrok; uji paket ini sendiri dahulu.

Saat naik kendaraan, elytra, creative flight, spectator, tidur, memanjat,
menyelinap, atau memakai item, animasi locomotion kustom dilepas untuk
memberi ruang pada pose bawaan. Server memeriksa pemain setiap 2 tick;
animasi hanya dikirim saat perubahan pose atau siklus perlu diperbarui.

## Pengaturan opsional

Default berjalan tanpa menyalakan eksperimen Beta APIs. Perintah pengaturan
membutuhkan cheats/izin operator karena menggunakan `/scriptevent`:

```text
/scriptevent bends_daffo:status
/scriptevent bends_daffo:chance 0.22
/scriptevent bends_daffo:enabled off
/scriptevent bends_daffo:enabled on
/scriptevent bends_daffo:demo knockdown
/scriptevent bends_daffo:demo chop
```

Chance harus 0 sampai 1, misalnya `0` mematikan peluang jatuh dan `1` membuat
setiap pukulan yang memenuhi syarat memicu jatuh setelah cooldown. Nilainya
disimpan di dynamic properties dunia. `enabled off` menghentikan pemicu
animasi baru; geometri resource pack tetap mengikuti subpack terpilih.

## Mengedit dan membangun ulang

Gunakan checkout yang sudah ada; tidak perlu worktree tambahan.

```bash
cd /workspace/danur/Bends-Daffo
npm ci --ignore-scripts
npm run typecheck
npm test
python3 tools/build.py
```

Build default **membuat ulang rig/actions** dari `tools/blender_author.py`.
Untuk mempertahankan edit artist di `.blend`, buka file di Blender, pilih
Action berawalan `BD_` di Action Editor, dan simpan perubahan. Lalu jalankan:

```bash
blender --background blender/Bends-Daffo.blend --threads 4 --python-exit-code 1 --python tools/export_blender.py
blender --background blender/Bends-Daffo.blend --threads 4 --python-exit-code 1 --python tools/verify_blender_export.py
python3 tools/build.py --skip-blender
npm run typecheck
npm test
```

Durasi klip tersimpan dalam custom property Action `bd_duration`, daftar bone
dalam `bd_bones`. Sesuaikan properti itu bila durasi atau daftar bone berubah.
Set rentang timeline sesuai durasi Action (30 FPS, frame awal 1). Semua Action
disimpan dengan Fake User agar tidak hilang. Pose preview berwarna tidak
diekspor sebagai texture game; resource pack memakai binding texture vanilla.

Exporter mengonversi basis Blender `(x,-z,y)` ke Bedrock `(x,y,z)`, local
rotation dalam derajat, posisi dalam unit model (16 unit = 1 blok), dan
sampling 30 FPS. Pivots/hierarki berada dalam geometry JSON.
Tanda rotasi X/Z dibalik sesuai konvensi Euler bone Bedrock agar gerak maju
dan arah tekukan sesuai dengan rig Blender. Gerak diekspor
ke `packs/BendsDaffo_RP/animations/bends_daffo.animation.json`; durasi runtime
di `scripts/clips.js` dibuat dari sumber yang sama.

## Validasi yang telah dilakukan

- Type check terhadap deklarasi resmi API 2.10.0.
- 16 tes perilaku dengan host/API mock, termasuk kedua pihak PvP, zombie jatuh,
  cooldown, prioritas reaksi, mining, locomotion, settings dan cleanup.
- Pemeriksaan manifest, UUID, dependencies, entrypoint, hierarki, UV dan
  referensi seluruh klip.
- Perbandingan numerik 24 Action / 5.606 bone-frame antara evaluasi Blender
  dan ekspor: kesalahan transform maksimum di bawah `1e-5`.
- Enam pose dirender dengan Blender CPU untuk inspeksi visual.

Tes mock membuktikan logika skrip, bukan networking Minecraft atau pemuatan
resource pack oleh game. Detail hasil dan checklist ada di
[docs/UJI_DALAM_GAME.md](docs/UJI_DALAM_GAME.md).

Sumber vanilla dipin ke tag resmi Mojang `v1.26.50.4`; lihat
[THIRD_PARTY.md](THIRD_PARTY.md) untuk atribusi dan ketentuan.
