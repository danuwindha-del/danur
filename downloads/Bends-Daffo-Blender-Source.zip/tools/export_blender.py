"""Run inside Blender; export evaluated local rig motion to Bedrock JSON.

Coordinate basis: Bedrock (x,y,z) -> Blender (x,-z,y), 16 model units/metre.
Bedrock's bone Euler convention reverses X/Z relative to right-handed XYZ.
Rig rest axes are identity (edit-bone tails point along Blender +Y).
Only local rotations/translations are exported; rest pivots live in geometry.
"""
import bpy
import json
import math
import sys
from pathlib import Path
from mathutils import Matrix

BASIS = Matrix(((1, 0, 0), (0, 0, -1), (0, 1, 0)))
INVERSE = BASIS.transposed()


def export(root):
    root = Path(root)
    rig = bpy.data.objects.get("BendsDaffo_Rig")
    if rig is None:
        raise RuntimeError("BendsDaffo_Rig not found in the .blend file")
    scene = bpy.context.scene
    scene.render.fps = 30
    animations = {}
    durations = {}
    report = {"blender_version": bpy.app.version_string, "fps": 30,
              "coordinate_basis": "Bedrock(x,y,z) -> Blender(x,-z,y), /16; native X/Z Euler signs reversed",
              "clips": {}}
    rig.animation_data_create()
    original = rig.animation_data.action
    original_frame = scene.frame_current
    for action in sorted(bpy.data.actions, key=lambda a: a.name):
        if not action.name.startswith("BD_"):
            continue
        clip = action.name[3:]
        duration = float(action["bd_duration"])
        count = round(duration * 30)
        duration = count / 30
        durations[clip] = round(duration, 6)
        rig.animation_data.action = action
        fp = clip.startswith("fp_")
        names = json.loads(action["bd_bones"])
        bones = {name: {"rotation": {}, "position": {}} for name in names}
        previous = {}
        for frame in range(count + 1):
            scene.frame_set(frame + 1)
            timestamp = f"{frame / 30:.6f}".rstrip("0").rstrip(".") or "0"
            for name in names:
                pose = rig.pose.bones[name]
                # Authoring rest axes are identity. matrix_basis is the actual
                # local animation delta, not a world-space bone transform.
                rotation = INVERSE @ pose.matrix_basis.to_3x3() @ BASIS
                euler = rotation.to_euler("XYZ", previous[name]) if name in previous else rotation.to_euler("XYZ")
                previous[name] = euler.copy()
                rot = [round(math.degrees(euler[0]) * -1, 4),
                       round(math.degrees(euler[1]), 4),
                       round(math.degrees(euler[2]) * -1, 4)]
                pos = [round(v * 16, 4) for v in INVERSE @ pose.matrix_basis.translation]
                bones[name]["rotation"][timestamp] = rot
                bones[name]["position"][timestamp] = pos
        # Remove constant zero channels, keeping an explicit identity rotation
        # where full-body clips need to reset a bone from preceding animations.
        for name in names:
            for channel in ["rotation", "position"]:
                values = list(bones[name][channel].values())
                if all(v == values[0] for v in values):
                    if channel == "position" and values[0] == [0, 0, 0]:
                        del bones[name][channel]
                    else:
                        bones[name][channel] = values[0]
        # Retain head aiming while using a full-body authored pose.
        if "head" in bones:
            track = bones["head"]["rotation"]
            def aim(value):
                return [f"query.target_x_rotation + ({value[0]})", f"query.target_y_rotation + ({value[1]})", value[2]]
            bones["head"]["rotation"] = {t: aim(v) for t, v in track.items()} if isinstance(track, dict) else aim(track)
        animations[f"animation.bends_daffo.{clip}"] = {
            "animation_length": round(duration, 6),
            "loop": False,
            "override_previous_animation": not fp and clip != "release",
            "blend_weight": "variable.is_first_person" if fp else
                ("1.0" if clip == "release" else "!variable.is_first_person && !variable.is_paperdoll && !variable.map_face_icon"),
            "bones": bones,
        }
        report["clips"][clip] = {"duration_seconds": round(duration, 6),
                                 "sample_count": count + 1, "bones": names}
    rig.animation_data.action = original
    scene.frame_set(original_frame)
    out = root / "packs/BendsDaffo_RP/animations/bends_daffo.animation.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"format_version": "1.8.0", "animations": animations},
                              separators=(",", ":")) + "\n")
    # Full-body durations form the single source of truth for server timing.
    durations = {k: v for k, v in durations.items() if not k.startswith("fp_")}
    (root / "packs/BendsDaffo_BP/scripts/clips.js").write_text(
        "// Generated from Blender actions. Re-export after editing motion.\n"
        "/** @type {Readonly<Record<string, number>>} */\n"
        "export const CLIPS = Object.freeze(" + json.dumps(durations, indent=2) + ");\n")
    (root / "blender/export-report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"EXPORTED {len(animations)} Blender actions to {out}")


if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    export(Path(args[0]) if args else Path(__file__).resolve().parents[1])
