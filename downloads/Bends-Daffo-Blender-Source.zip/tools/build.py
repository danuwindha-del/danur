#!/usr/bin/env python3
"""Build Bends-Daffo packs from pinned Mojang definitions and Blender motion."""
import argparse
import copy
import hashlib
import json
import struct
import subprocess
import sys
import uuid
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "vendor/mojang/resource_pack"
PACKS = ROOT / "packs"
RP = PACKS / "BendsDaffo_RP"
BP = PACKS / "BendsDaffo_BP"
VERSION = [1, 0, 0]
ENGINE = [1, 26, 50]
NAMESPACE = uuid.UUID("345bbdeb-59a6-4bc0-937f-deb4f118b9ab")


def uid(name):
    return str(uuid.uuid5(NAMESPACE, name))


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def load(path):
    return json.loads(path.read_text())


def modern_geometry(source):
    if "minecraft:geometry" in source:
        return copy.deepcopy(source["minecraft:geometry"])
    out = []
    for identifier, g in source.items():
        if not identifier.startswith("geometry."):
            continue
        out.append({"description": {
            "identifier": identifier,
            "texture_width": g.get("texturewidth", 64),
            "texture_height": g.get("textureheight", 64),
            "visible_bounds_width": g.get("visible_bounds_width", 2),
            "visible_bounds_height": g.get("visible_bounds_height", 2),
            "visible_bounds_offset": g.get("visible_bounds_offset", [0, 1, 0]),
        }, "bones": copy.deepcopy(g["bones"])})
    return out


def half_cube(cube, lower):
    """Split a box without stretching the skin texture across each half."""
    c = copy.deepcopy(cube)
    w, h, d = c["size"]
    u, v = c["uv"]
    new_h = h / 2
    c["size"][1] = new_h
    if not lower:
        c["origin"][1] += new_h
    top_offset = new_h if lower else 0
    c["uv"] = {
        "north": {"uv": [u + d, v + d + top_offset], "uv_size": [w, new_h]},
        "east": {"uv": [u, v + d + top_offset], "uv_size": [d, new_h]},
        "south": {"uv": [u + 2*d + w, v + d + top_offset], "uv_size": [w, new_h]},
        "west": {"uv": [u + d + w, v + d + top_offset], "uv_size": [d, new_h]},
        "up": {"uv": [u + d, v], "uv_size": [w, d]},
        "down": {"uv": [u + d + w, v + d], "uv_size": [w, -d]},
    }
    return c


def segmented(g, name):
    g = copy.deepcopy(g)
    desc = g["description"]
    desc.update(identifier=f"geometry.bends_daffo.{name}",
                texture_width=desc.get("texture_width", 64),
                texture_height=desc.get("texture_height", 64),
                visible_bounds_width=5, visible_bounds_height=4,
                visible_bounds_offset=[0, 1, 0])
    bones = g["bones"]
    by_name = {b["name"]: b for b in bones}
    if "root" not in by_name:
        root = {"name": "root", "pivot": [0, 0, 0]}
        bones.insert(0, root)
        by_name["root"] = root
    by_name["waist"]["parent"] = "root"
    for side, x in [("right", -1), ("left", 1)]:
        for limb, child, overlay in [("Arm", "ForeArm", "Sleeve"), ("Leg", "Shin", "Pants")]:
            base_name = side + limb
            b = by_name[base_name]
            if limb == "Leg":
                b["parent"] = "root"
            lower = {"name": side + child, "parent": base_name,
                     "pivot": [x * (6 if limb == "Arm" else 1.9), 18 if limb == "Arm" else 6, 0],
                     "cubes": [half_cube(c, True) for c in b["cubes"]]}
            if b.get("mirror"):
                lower["mirror"] = True
            b["cubes"] = [half_cube(c, False) for c in b["cubes"]]
            bones.append(lower)
            layer_name = side + overlay
            if layer_name in by_name:
                layer = by_name[layer_name]
                lower_layer = copy.deepcopy(layer)
                lower_layer.update(name=side + child + overlay, parent=side + child, pivot=lower["pivot"])
                lower_layer["cubes"] = [half_cube(c, True) for c in layer["cubes"]]
                layer["cubes"] = [half_cube(c, False) for c in layer["cubes"]]
                bones.append(lower_layer)
            if limb == "Arm" and side + "Item" in by_name:
                by_name[side + "Item"]["parent"] = side + child
    return g


def icon(path):
    """Small original pixel logo; PNG encoding uses only the standard library."""
    size = 128
    pixels = [[(12, 24, 35, 255) for _ in range(size)] for _ in range(size)]
    for y in range(8, 120):
        for x in range(8, 120):
            if min(x, y, 127-x, 127-y) < 12:
                pixels[y][x] = (22, 190, 161, 255)
    glyphs = [(["1110", "1001", "1110", "1001", "1110"], 27),
              (["1110", "1001", "1001", "1001", "1110"], 69)]
    for glyph, left in glyphs:
        for row, line in enumerate(glyph):
            for col, char in enumerate(line):
                if char == "1":
                    for y in range(42 + row*9, 51 + row*9):
                        for x in range(left + col*9, left + (col+1)*9):
                            pixels[y][x] = (235, 250, 244, 255)
    data = b"".join(b"\0" + bytes(c for px in row for c in px) for row in pixels)
    def chunk(kind, content):
        return struct.pack(">I", len(content)) + kind + content + struct.pack(">I", zlib.crc32(kind + content))
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)) +
                     chunk(b"IDAT", zlib.compress(data)) + chunk(b"IEND", b""))


def generate_packs():
    manifest_base = {"format_version": 2, "metadata": {"authors": ["Bends-Daffo"], "license": "See THIRD_PARTY.md; original implementation MIT."}}
    resource = copy.deepcopy(manifest_base)
    resource["header"] = {"name": "Bends-Daffo • Animations", "description": "Animasi Blender: pukul, lompat, renang, tebang, jatuh & bangkit. Bedrock 26.50.", "uuid": uid("rp-header"), "version": VERSION, "min_engine_version": ENGINE}
    resource["modules"] = [{"type": "resources", "uuid": uid("rp-module"), "version": VERSION}]
    resource["subpacks"] = [
        {"folder_name": "bends", "name": "Sendi siku/lutut — skin klasik Steve", "memory_tier": 0},
        {"folder_name": "compat", "name": "Skin kompatibel — gerak dasar, sendi bawaan", "memory_tier": 0},
    ]
    behavior = copy.deepcopy(manifest_base)
    behavior["header"] = {"name": "Bends-Daffo • Runtime", "description": "Animasi dan reaksi multiplayer dari server. Stable Script API 2.10.0.", "uuid": uid("bp-header"), "version": VERSION, "min_engine_version": ENGINE}
    behavior["modules"] = [
        {"type": "data", "uuid": uid("bp-data-module"), "version": VERSION},
        {"type": "script", "language": "javascript", "entry": "scripts/main.js", "uuid": uid("bp-script-module"), "version": VERSION},
    ]
    behavior["dependencies"] = [{"module_name": "@minecraft/server", "version": "2.10.0"}, {"uuid": uid("rp-header"), "version": VERSION}]
    dump(RP / "manifest.json", resource)
    dump(BP / "manifest.json", behavior)
    clips = load(ROOT / "blender/export-report.json")["clips"]
    dump(RP / "animation_controllers/bends_daffo.controller.json", {
        "format_version": "1.10.0",
        "animation_controllers": {
            "controller.animation.bends_daffo.pose": {"initial_state": "default", "states": {"default": {}}},
            "controller.animation.bends_daffo.arms": {"initial_state": "default", "states": {"default": {}}},
        },
    })
    for mob in ["player", "zombie", "husk", "drowned"]:
        source = load(VENDOR / f"entity/{mob}.entity.json")
        desc = source["minecraft:client_entity"]["description"]
        # Keep vanilla initialization, controllers, skin texture bindings,
        # first-person rendering, attachables, baby variants and new 26.50 items.
        for clip in clips:
            desc.setdefault("animations", {})["bd_" + clip] = "animation.bends_daffo." + clip
        desc["animations"].update(bends_daffo_pose="controller.animation.bends_daffo.pose",
                                  bends_daffo_arms="controller.animation.bends_daffo.arms")
        desc["scripts"]["animate"].extend(["bends_daffo_pose", "bends_daffo_arms"])
        if mob != "player":
            desc["scripts"].setdefault("initialize", []).extend([
                "variable.is_first_person = 0;", "variable.is_paperdoll = 0;", "variable.map_face_icon = 0;",
            ])
        # Compatible mode keeps vanilla geometry; action playback still works
        # on the original bones, while extra joints are simply unused.
        dump(RP / f"subpacks/compat/entity/{mob}.entity.json", source)
        desc["geometry"]["default"] = f"geometry.bends_daffo.{mob}"
        dump(RP / f"entity/{mob}.entity.json", source)
    dump(RP / "subpacks/bends/selection.json", {"note": "Uses the root pack's segmented geometry."})
    geometry = []
    for name, file in [("player", "humanoid.custom.geo.json"), ("zombie", "zombie.geo.json"), ("husk", "husk.geo.json"), ("drowned", "drowned.geo.json")]:
        g = modern_geometry(load(VENDOR / f"models/entity/{file}"))[0]
        geometry.append(segmented(g, name))
    dump(RP / "models/entity/bends_daffo.geo.json", {"format_version": "1.12.0", "minecraft:geometry": geometry})
    renders = load(VENDOR / "render_controllers/player.render_controllers.json")
    dump(RP / "subpacks/compat/render_controllers/player.render_controllers.json", renders)
    fp = renders["render_controllers"]["controller.render.player.first_person"]
    arm_visibility = {list(r.keys())[0]: list(r.values())[0] for r in fp["part_visibility"]}
    for side in ["right", "left"]:
        for bone in [side + "ForeArm", side + "ForeArmSleeve"]:
            fp["part_visibility"].append({bone: arm_visibility[side + "Arm"]})
    dump(RP / "render_controllers/player.render_controllers.json", renders)
    for pack in [RP, BP]:
        icon(pack / "pack_icon.png")
        (pack / "LICENSE.txt").write_text((ROOT / "LICENSE").read_text())
        (pack / "THIRD_PARTY.md").write_text((ROOT / "THIRD_PARTY.md").read_text())
    (RP / "texts").mkdir(exist_ok=True)
    dump(RP / "texts/languages.json", ["en_US", "id_ID"])
    for language in ["en_US", "id_ID"]:
        (RP / f"texts/{language}.lang").write_text("pack.name=Bends-Daffo\npack.description=Blender-authored movement and multiplayer combat reactions\n")


def archive():
    out = ROOT / "dist"
    out.mkdir(exist_ok=True)
    for pack in [RP, BP]:
        with zipfile.ZipFile(out / (pack.name + ".mcpack"), "w", zipfile.ZIP_DEFLATED) as z:
            for file in sorted(pack.rglob("*")):
                if file.is_file():
                    # Deterministic archives: stable timestamps and POSIX names.
                    info = zipfile.ZipInfo(file.relative_to(pack).as_posix(), (2026, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    z.writestr(info, file.read_bytes())
    addon = out / "Bends-Daffo-1.0.0-Bedrock-26.50.mcaddon"
    with zipfile.ZipFile(addon, "w", zipfile.ZIP_STORED) as z:
        for file in sorted(out.glob("*.mcpack")):
            info = zipfile.ZipInfo(file.name, (2026, 1, 1, 0, 0, 0))
            z.writestr(info, file.read_bytes())
    bundle = out / "Bends-Daffo-Blender-Source.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
        for directory in ["blender", "tools", "docs", "vendor", "packs"]:
            for f in sorted((ROOT / directory).rglob("*")):
                if f.is_file() and f.suffix not in [".blend1", ".blend2", ".pyc"]:
                    z.write(f, f.relative_to(ROOT))
        for f in ["README.md", "LICENSE", "THIRD_PARTY.md", "package.json", "package-lock.json", "jsconfig.json"]:
            if (ROOT / f).exists():
                z.write(ROOT / f, f)
        for f in sorted((ROOT / "tests").glob("*.js")):
            z.write(f, f.relative_to(ROOT))
    checksums = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.glob("*")) if f.suffix in [".mcpack", ".mcaddon", ".zip"]}
    dump(out / "SHA256.json", checksums)
    print(f"BUILT {addon} ({addon.stat().st_size:,} bytes)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-blender", action="store_true", help="Keep existing exported/editable Blender actions")
    args = parser.parse_args()
    if not args.skip_blender:
        subprocess.run(["blender", "--background", "--python-exit-code", "1", "--python", str(ROOT / "tools/blender_author.py")], check=True)
    generate_packs()
    subprocess.run([sys.executable, str(ROOT / "tools/validate.py")], check=True)
    archive()
