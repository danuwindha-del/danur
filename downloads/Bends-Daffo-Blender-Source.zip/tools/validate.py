#!/usr/bin/env python3
"""Validate package links, geometry hierarchy, UVs and Blender export coverage.

These checks do not replace Minecraft's runtime/content log or visual tests.
"""
import json
import math
import re
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BP = ROOT / "packs/BendsDaffo_BP"
RP = ROOT / "packs/BendsDaffo_RP"


def load(path):
    return json.loads(path.read_text())


def validate():
    files = list((ROOT / "packs").rglob("*.json"))
    for file in files:
        load(file)
    bp, rp = load(BP / "manifest.json"), load(RP / "manifest.json")
    ids = []
    for m, root in [(bp, BP), (rp, RP)]:
        assert m["format_version"] == 2
        assert m["header"]["min_engine_version"] == [1, 26, 50]
        assert m["header"]["version"] == [1, 0, 0]
        ids.append(m["header"]["uuid"])
        for module in m["modules"]:
            ids.append(module["uuid"])
            if module["type"] == "script":
                assert module["language"] == "javascript"
                assert (root / module["entry"]).is_file()
        assert (root / "pack_icon.png").read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
    for identity in ids:
        uuid.UUID(identity)
    assert len(set(ids)) == len(ids)
    assert {"uuid": rp["header"]["uuid"], "version": [1, 0, 0]} in bp["dependencies"]
    assert {"module_name": "@minecraft/server", "version": "2.10.0"} in bp["dependencies"]
    for script in (BP / "scripts").glob("*.js"):
        for imported in re.findall(r'from\s+[\'\"]([^\'\"]+)[\'\"]', script.read_text()):
            if imported.startswith("."):
                assert (script.parent / imported).is_file(), imported
            else:
                assert imported == "@minecraft/server"
    animations = load(RP / "animations/bends_daffo.animation.json")["animations"]
    controllers = load(RP / "animation_controllers/bends_daffo.controller.json")["animation_controllers"]
    for controller in controllers.values():
        assert controller["initial_state"] == "default"
        assert "default" in controller["states"]
    report = load(ROOT / "blender/export-report.json")
    assert report["fps"] == 30
    assert len(animations) == len(report["clips"])
    required = {"punch_right", "punch_left", "strike", "chop", "mine", "jump", "land", "swim", "hurt_left", "hurt_right", "knockdown"}
    assert required <= set(report["clips"])
    sampled_vectors = 0
    for identifier, animation in animations.items():
        clip = identifier.removeprefix("animation.bends_daffo.")
        length = animation["animation_length"]
        assert length == report["clips"][clip]["duration_seconds"]
        assert length > 0
        assert isinstance(animation["blend_weight"], str)
        for name, channels in animation["bones"].items():
            for channel, track in channels.items():
                assert channel in ["rotation", "position"]
                if isinstance(track, dict):
                    times = [float(t) for t in track]
                    assert min(times) == 0
                    assert abs(max(times) - length) < 1e-5
                    assert times == sorted(times)
                    vectors = track.values()
                else:
                    vectors = [track]
                for v in vectors:
                    assert len(v) == 3
                    for x in v:
                        assert (isinstance(x, (int, float)) and math.isfinite(x)) or (name == "head" and isinstance(x, str) and re.fullmatch(r"query\.target_[xy]_rotation \+ \([-\d.]+\)", x))
                    sampled_vectors += 1
    geo = load(RP / "models/entity/bends_daffo.geo.json")["minecraft:geometry"]
    geometries = {}
    for geometry in geo:
        d = geometry["description"]
        geometries[d["identifier"]] = geometry
        bones = {b["name"]: b for b in geometry["bones"]}
        assert len(bones) == len(geometry["bones"])
        assert {"root", "waist", "body", "head", "rightForeArm", "leftForeArm", "rightShin", "leftShin"} <= set(bones)
        for b in bones.values():
            visited = {b["name"]}
            current = b
            while "parent" in current:
                assert current["parent"] in bones
                assert current["parent"] not in visited, "Bone parent cycle"
                visited.add(current["parent"])
                current = bones[current["parent"]]
            for cube in b.get("cubes", []):
                assert all(v > 0 for v in cube["size"])
                if isinstance(cube["uv"], dict):
                    for face in cube["uv"].values():
                        for axis, limit in enumerate([d["texture_width"], d["texture_height"]]):
                            a, size = face["uv"][axis], face["uv_size"][axis]
                            assert 0 <= min(a, a + size) <= max(a, a + size) <= limit, (d["identifier"], b["name"], face)
        for action in animations.values():
            assert set(action["bones"]) <= set(bones)
        for side in ["right", "left"]:
            assert bones[side + "Item"]["parent"] == side + "ForeArm"
            assert bones[side + "Leg"]["parent"] == "root"
    for mob in ["player", "zombie", "husk", "drowned"]:
        desc = load(RP / f"entity/{mob}.entity.json")["minecraft:client_entity"]["description"]
        assert desc["identifier"] == f"minecraft:{mob}"
        assert desc["geometry"]["default"] in geometries
        assert desc["enable_attachables"] is True
        for alias in ["bends_daffo_pose", "bends_daffo_arms"]:
            assert desc["animations"][alias] in controllers
            assert alias in desc["scripts"]["animate"]
        assert all("animation.bends_daffo." + clip in desc["animations"].values() for clip in report["clips"])
        compat = load(RP / f"subpacks/compat/entity/{mob}.entity.json")["minecraft:client_entity"]["description"]
        assert not compat["geometry"]["default"].startswith("geometry.bends_daffo.")
    rig = ROOT / "blender/Bends-Daffo.blend"
    assert rig.read_bytes().startswith(b"BLENDER"), "Editable Blender source missing"
    print(f"VALIDATED: {len(files)} JSON files, {len(geo)} segmented geometries, {len(animations)} Blender clips, {sampled_vectors} sampled vectors; manifests, dependencies, UVs, references OK.")
    print("Minecraft runtime, content log, skins, armor and two-client synchronization: require in-game validation.")


if __name__ == "__main__":
    validate()
