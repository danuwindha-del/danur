"""Independent evaluated-rig / exported-Molang-channel numeric comparison."""
import bpy
import json
import math
import re
from pathlib import Path
from mathutils import Matrix, Euler, Vector

ROOT = Path(__file__).resolve().parents[1]
C = Matrix(((1, 0, 0), (0, 0, -1), (0, 1, 0)))
animations = json.loads((ROOT / "packs/BendsDaffo_RP/animations/bends_daffo.animation.json").read_text())["animations"]
rig = bpy.data.objects["BendsDaffo_Rig"]
samples = 0
maximum = 0

# Known Bedrock pose: -90 X raises a downward arm towards model front (-Z).
# This catches a consistent but incorrect roundtrip of right-handed signs.
front = Euler((math.pi / 2, 0, 0), "XYZ").to_matrix() @ Vector((0, -1, 0))
assert (front - Vector((0, 0, -1))).length < 1e-6
impact = animations["animation.bends_daffo.punch_right"]["bones"]["rightArm"]["rotation"]["0.2"]
assert abs(impact[0] + 90) < 1e-3, "Jab must point forward using native Bedrock negative-X rotation"


def sample(track, time):
    if isinstance(track, list):
        result = track
    else:
        key = f"{time:.6f}".rstrip("0").rstrip(".") or "0"
        result = track[key]
    # Aim queries represent a dynamic additive head offset. Set aim=0 here
    # to compare the underlying authored head motion to Blender exactly.
    return [float(re.search(r"\(([-\d.]+)\)", v)[1]) if isinstance(v, str) else v for v in result]


for identifier, animation in animations.items():
    name = identifier.split("animation.bends_daffo.", 1)[1]
    rig.animation_data.action = bpy.data.actions["BD_" + name]
    count = round(animation["animation_length"] * 30)
    for i in range(count + 1):
        bpy.context.scene.frame_set(i + 1)
        for bone, tracks in animation["bones"].items():
            r = sample(tracks["rotation"], i / 30)
            physical = (-r[0], r[1], -r[2])
            exported_rotation = C @ Euler(tuple(math.radians(v) for v in physical), "XYZ").to_matrix() @ C.transposed()
            actual = rig.pose.bones[bone].matrix_basis
            error = max(abs(exported_rotation[row][col] - actual[row][col]) for row in range(3) for col in range(3))
            pos = C @ Vector(sample(tracks.get("position", [0, 0, 0]), i / 30)) / 16
            error = max(error, (pos - actual.translation).length)
            maximum = max(maximum, error)
            assert error < 1e-5, (name, i, bone, error)
            samples += 1
print(f"BLENDER ROUNDTRIP PASSED: {len(animations)} actions, {samples} bone-frame samples, max transform error {maximum:.8g}.")
