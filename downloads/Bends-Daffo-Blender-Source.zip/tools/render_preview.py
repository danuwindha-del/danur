"""Blender preview renders, explicitly separate from Minecraft screenshots."""
import bpy
import sys
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
rig = bpy.data.objects["BendsDaffo_Rig"]
scene = bpy.context.scene
scene.render.resolution_x = 800
scene.render.resolution_y = 620
scene.cycles.samples = 20
scene.cycles.use_denoising = False
camera = scene.camera
selected = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
for clip, frame in [("punch_right", 7), ("chop", 9), ("jump", 5), ("swim", 12), ("knockdown", 25), ("run", 5)]:
    if selected and clip not in selected:
        continue
    rig.animation_data.action = bpy.data.actions["BD_" + clip]
    scene.frame_set(frame)
    depsgraph = bpy.context.evaluated_depsgraph_get()
    points = []
    for child in rig.children:
        if child.type == "MESH":
            evaluated = child.evaluated_get(depsgraph)
            points.extend(evaluated.matrix_world @ Vector(v) for v in evaluated.bound_box)
    minimum = Vector(tuple(min(p[i] for p in points) for i in range(3)))
    maximum = Vector(tuple(max(p[i] for p in points) for i in range(3)))
    center = (minimum + maximum) / 2
    camera.location = center + Vector((3.7, 5.6, 3.0))
    camera.rotation_euler = (center - camera.location).to_track_quat("-Z", "Y").to_euler()
    camera.data.ortho_scale = 3.3
    scene.render.filepath = str(ROOT / f"blender/preview-{clip}.png")
    bpy.ops.render.render(write_still=True)
    print(f"PREVIEW: {clip}", flush=True)
