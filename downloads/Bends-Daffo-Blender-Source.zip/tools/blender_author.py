"""Generate editable block-humanoid rig and authored actions in Blender 4.3+."""
import bpy
import math
import sys
import json
from pathlib import Path
from mathutils import Euler, Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
from export_blender import BASIS, INVERSE, export

ROOT = Path(__file__).resolve().parents[1]
BONES = {
    "root": (None, (0, 0, 0)),
    "waist": ("root", (0, 12, 0)),
    "body": ("waist", (0, 24, 0)),
    "head": ("body", (0, 24, 0)),
    "rightArm": ("body", (-5, 22, 0)),
    "rightForeArm": ("rightArm", (-6, 18, 0)),
    "leftArm": ("body", (5, 22, 0)),
    "leftForeArm": ("leftArm", (6, 18, 0)),
    "rightLeg": ("root", (-1.9, 12, 0)),
    "rightShin": ("rightLeg", (-1.9, 6, 0)),
    "leftLeg": ("root", (1.9, 12, 0)),
    "leftShin": ("leftLeg", (1.9, 6, 0)),
}


def pose(**kw):
    return kw


# Degrees in Bedrock model axes, not pre-baked animation JSON. These poses
# become native Blender actions with Bezier F-curves, then are sampled/exported.
CLIPS = {
    "idle": (2.0, [
        (0, pose(body=(1, 0, 0), rightArm=(0, 0, 3), leftArm=(0, 0, -3), rightForeArm=(-6, 0, 0), leftForeArm=(-6, 0, 0))),
        (1, pose(body=(-1, 0, 0), rightArm=(-1, 0, 2), leftArm=(1, 0, -2), rightForeArm=(-8, 0, 0), leftForeArm=(-8, 0, 0))),
        (2, pose(body=(1, 0, 0), rightArm=(0, 0, 3), leftArm=(0, 0, -3), rightForeArm=(-6, 0, 0), leftForeArm=(-6, 0, 0))),
    ]),
    "walk": (1.0, [
        (0, pose(body=(3, -4, 1), rightArm=(24, 0, 2), leftArm=(-24, 0, -2), rightForeArm=(-14, 0, 0), leftForeArm=(-20, 0, 0), rightLeg=(-28, 0, 0), leftLeg=(28, 0, 0), rightShin=(8, 0, 0), leftShin=(24, 0, 0))),
        (.25, pose(body=(4, 0, -1), rightArm=(0, 0, 3), leftArm=(0, 0, -3), rightForeArm=(-20, 0, 0), leftForeArm=(-14, 0, 0), rightLeg=(0, 0, 0), leftLeg=(0, 0, 0), rightShin=(32, 0, 0), leftShin=(5, 0, 0), root_pos=(0, .5, 0))),
        (.5, pose(body=(3, 4, -1), rightArm=(-24, 0, 2), leftArm=(24, 0, -2), rightForeArm=(-20, 0, 0), leftForeArm=(-14, 0, 0), rightLeg=(28, 0, 0), leftLeg=(-28, 0, 0), rightShin=(24, 0, 0), leftShin=(8, 0, 0))),
        (.75, pose(body=(4, 0, 1), rightArm=(0, 0, 3), leftArm=(0, 0, -3), rightForeArm=(-14, 0, 0), leftForeArm=(-20, 0, 0), rightLeg=(0, 0, 0), leftLeg=(0, 0, 0), rightShin=(5, 0, 0), leftShin=(32, 0, 0), root_pos=(0, .5, 0))),
        (1, pose(body=(3, -4, 1), rightArm=(24, 0, 2), leftArm=(-24, 0, -2), rightForeArm=(-14, 0, 0), leftForeArm=(-20, 0, 0), rightLeg=(-28, 0, 0), leftLeg=(28, 0, 0), rightShin=(8, 0, 0), leftShin=(24, 0, 0))),
    ]),
    "run": (.6, [
        (0, pose(body=(12, -9, 2), rightArm=(48, 0, 5), leftArm=(-48, 0, -5), rightForeArm=(-70, 0, 0), leftForeArm=(-85, 0, 0), rightLeg=(-52, 0, 0), leftLeg=(45, 0, 0), rightShin=(18, 0, 0), leftShin=(82, 0, 0))),
        (.15, pose(body=(14, 0, 0), rightForeArm=(-80, 0, 0), leftForeArm=(-80, 0, 0), rightLeg=(8, 0, 0), leftLeg=(-8, 0, 0), rightShin=(85, 0, 0), leftShin=(30, 0, 0), root_pos=(0, 1.2, 0))),
        (.3, pose(body=(12, 9, -2), rightArm=(-48, 0, 5), leftArm=(48, 0, -5), rightForeArm=(-85, 0, 0), leftForeArm=(-70, 0, 0), rightLeg=(45, 0, 0), leftLeg=(-52, 0, 0), rightShin=(82, 0, 0), leftShin=(18, 0, 0))),
        (.45, pose(body=(14, 0, 0), rightForeArm=(-80, 0, 0), leftForeArm=(-80, 0, 0), rightLeg=(-8, 0, 0), leftLeg=(8, 0, 0), rightShin=(30, 0, 0), leftShin=(85, 0, 0), root_pos=(0, 1.2, 0))),
        (.6, pose(body=(12, -9, 2), rightArm=(48, 0, 5), leftArm=(-48, 0, -5), rightForeArm=(-70, 0, 0), leftForeArm=(-85, 0, 0), rightLeg=(-52, 0, 0), leftLeg=(45, 0, 0), rightShin=(18, 0, 0), leftShin=(82, 0, 0))),
    ]),
    "punch_right": (.5, [
        (0, pose()),
        (.10, pose(body=(3, -20, -4), rightArm=(-65, -15, 12), rightForeArm=(-100, 0, 0), leftArm=(-35, 0, -12), leftForeArm=(-95, 0, 0), rightLeg=(12, 0, 0), leftLeg=(-10, 0, 0))),
        (.20, pose(body=(7, 28, 5), rightArm=(-90, -18, -7), rightForeArm=(-12, 0, 0), leftArm=(-42, 0, -12), leftForeArm=(-105, 0, 0), rightLeg=(-8, 0, 0), leftLeg=(8, 0, 0), root_pos=(0, -.35, -.6))),
        (.30, pose(body=(4, 12, 2), rightArm=(-70, -8, 3), rightForeArm=(-55, 0, 0), leftArm=(-30, 0, -7), leftForeArm=(-90, 0, 0))),
        (.5, pose()),
    ]),
    "punch_left": (.5, [
        (0, pose()),
        (.10, pose(body=(3, 20, 4), leftArm=(-65, 15, -12), leftForeArm=(-100, 0, 0), rightArm=(-35, 0, 12), rightForeArm=(-95, 0, 0), leftLeg=(12, 0, 0), rightLeg=(-10, 0, 0))),
        (.20, pose(body=(7, -28, -5), leftArm=(-90, 18, 7), leftForeArm=(-12, 0, 0), rightArm=(-42, 0, 12), rightForeArm=(-105, 0, 0), leftLeg=(-8, 0, 0), rightLeg=(8, 0, 0), root_pos=(0, -.35, -.6))),
        (.30, pose(body=(4, -12, -2), leftArm=(-70, 8, -3), leftForeArm=(-55, 0, 0), rightArm=(-30, 0, 7), rightForeArm=(-90, 0, 0))),
        (.5, pose()),
    ]),
    "strike": (.7, [
        (0, pose()),
        (.17, pose(body=(-4, -32, -7), rightArm=(-145, -25, 22), rightForeArm=(-65, 0, 0), leftArm=(-40, 0, -20), leftForeArm=(-80, 0, 0))),
        (.30, pose(body=(18, 25, 6), rightArm=(-55, 20, -12), rightForeArm=(-10, 0, 0), leftArm=(-30, 0, -15), leftForeArm=(-65, 0, 0), rightLeg=(-15, 0, 0), rightShin=(22, 0, 0), root_pos=(0, -.8, -.6))),
        (.43, pose(body=(10, 35, 5), rightArm=(-10, 25, -20), rightForeArm=(-22, 0, 0))),
        (.7, pose()),
    ]),
    "chop": (.9, [
        (0, pose(body=(3, 0, 0), rightArm=(-25, 0, 8), rightForeArm=(-40, 0, 0))),
        (.27, pose(body=(-8, -16, -4), rightArm=(-150, 0, 13), rightForeArm=(-62, 0, 0), leftArm=(-30, 0, -12), leftForeArm=(-75, 0, 0))),
        (.43, pose(body=(18, 15, 4), rightArm=(-65, 12, -4), rightForeArm=(-8, 0, 0), leftArm=(-30, 0, -12), leftForeArm=(-55, 0, 0), rightLeg=(-8, 0, 0), leftLeg=(-8, 0, 0), rightShin=(15, 0, 0), leftShin=(15, 0, 0), root_pos=(0, -.7, 0))),
        (.6, pose(body=(10, 8, 2), rightArm=(-40, 5, 3), rightForeArm=(-32, 0, 0))),
        (.9, pose(body=(3, 0, 0), rightArm=(-25, 0, 8), rightForeArm=(-40, 0, 0))),
    ]),
    "mine": (.6, [
        (0, pose(rightArm=(-35, 0, 4), rightForeArm=(-30, 0, 0))),
        (.17, pose(body=(0, -10, -3), rightArm=(-120, 0, 8), rightForeArm=(-70, 0, 0))),
        (.30, pose(body=(10, 10, 3), rightArm=(-55, 5, 0), rightForeArm=(-12, 0, 0))),
        (.6, pose(rightArm=(-35, 0, 4), rightForeArm=(-30, 0, 0))),
    ]),
    "jump": (.4, [
        (0, pose(body=(6, 0, 0), rightLeg=(-15, 0, 0), leftLeg=(-15, 0, 0), rightShin=(25, 0, 0), leftShin=(25, 0, 0))),
        (.13, pose(body=(-4, 0, 0), rightArm=(-50, 0, 10), leftArm=(-50, 0, -10), rightForeArm=(-35, 0, 0), leftForeArm=(-35, 0, 0), rightLeg=(-28, 0, 0), leftLeg=(-42, 0, 0), rightShin=(55, 0, 0), leftShin=(70, 0, 0))),
        (.4, pose(body=(6, 0, 0), rightArm=(10, 0, 15), leftArm=(10, 0, -15), rightForeArm=(-25, 0, 0), leftForeArm=(-25, 0, 0), rightLeg=(-22, 0, 0), leftLeg=(-15, 0, 0), rightShin=(40, 0, 0), leftShin=(30, 0, 0))),
    ]),
    "fall": (.8, [
        (0, pose(body=(7, 0, 0), rightArm=(15, 0, 28), leftArm=(15, 0, -28), rightForeArm=(-28, 0, 0), leftForeArm=(-28, 0, 0), rightLeg=(-18, 0, 0), leftLeg=(-10, 0, 0), rightShin=(30, 0, 0), leftShin=(22, 0, 0))),
        (.4, pose(body=(10, 0, 0), rightArm=(10, 0, 34), leftArm=(10, 0, -34), rightForeArm=(-35, 0, 0), leftForeArm=(-35, 0, 0), rightLeg=(-22, 0, 0), leftLeg=(-15, 0, 0), rightShin=(38, 0, 0), leftShin=(28, 0, 0))),
        (.8, pose(body=(7, 0, 0), rightArm=(15, 0, 28), leftArm=(15, 0, -28), rightForeArm=(-28, 0, 0), leftForeArm=(-28, 0, 0), rightLeg=(-18, 0, 0), leftLeg=(-10, 0, 0), rightShin=(30, 0, 0), leftShin=(22, 0, 0))),
    ]),
    "land": (.3, [
        (0, pose()),
        (.10, pose(body=(20, 0, 0), root_pos=(0, -2.2, 0), rightLeg=(-35, 0, 0), leftLeg=(-35, 0, 0), rightShin=(62, 0, 0), leftShin=(62, 0, 0), rightArm=(25, 0, 12), leftArm=(25, 0, -12), rightForeArm=(-35, 0, 0), leftForeArm=(-35, 0, 0))),
        (.3, pose()),
    ]),
    "swim": (1.2, [
        (0, pose(root=(80, 0, 0), root_pos=(0, 3, 0), body=(0, 0, -8), rightArm=(-155, 0, 15), rightForeArm=(-15, 0, 0), leftArm=(-10, 0, -30), leftForeArm=(-95, 0, 0), rightLeg=(-12, 0, 0), leftLeg=(12, 0, 0), rightShin=(25, 0, 0), leftShin=(12, 0, 0))),
        (.3, pose(root=(80, 0, 0), root_pos=(0, 3, 0), rightArm=(-80, 0, 55), rightForeArm=(-70, 0, 0), leftArm=(-90, 0, -10), leftForeArm=(-25, 0, 0), rightLeg=(12, 0, 0), leftLeg=(-12, 0, 0), rightShin=(12, 0, 0), leftShin=(25, 0, 0))),
        (.6, pose(root=(80, 0, 0), root_pos=(0, 3, 0), body=(0, 0, 8), rightArm=(-10, 0, 30), rightForeArm=(-95, 0, 0), leftArm=(-155, 0, -15), leftForeArm=(-15, 0, 0), rightLeg=(-12, 0, 0), leftLeg=(12, 0, 0), rightShin=(25, 0, 0), leftShin=(12, 0, 0))),
        (.9, pose(root=(80, 0, 0), root_pos=(0, 3, 0), rightArm=(-90, 0, 10), rightForeArm=(-25, 0, 0), leftArm=(-80, 0, -55), leftForeArm=(-70, 0, 0), rightLeg=(12, 0, 0), leftLeg=(-12, 0, 0), rightShin=(12, 0, 0), leftShin=(25, 0, 0))),
        (1.2, pose(root=(80, 0, 0), root_pos=(0, 3, 0), body=(0, 0, -8), rightArm=(-155, 0, 15), rightForeArm=(-15, 0, 0), leftArm=(-10, 0, -30), leftForeArm=(-95, 0, 0), rightLeg=(-12, 0, 0), leftLeg=(12, 0, 0), rightShin=(25, 0, 0), leftShin=(12, 0, 0))),
    ]),
    "tread_water": (1.2, [
        (0, pose(body=(5, 0, 0), rightArm=(-35, 0, 40), leftArm=(-35, 0, -40), rightForeArm=(-55, 0, 0), leftForeArm=(-55, 0, 0), rightLeg=(-22, 0, 5), leftLeg=(12, 0, -5), rightShin=(40, 0, 0), leftShin=(20, 0, 0))),
        (.6, pose(body=(2, 0, 0), rightArm=(-10, 0, 30), leftArm=(-10, 0, -30), rightForeArm=(-70, 0, 0), leftForeArm=(-70, 0, 0), rightLeg=(12, 0, 5), leftLeg=(-22, 0, -5), rightShin=(20, 0, 0), leftShin=(40, 0, 0))),
        (1.2, pose(body=(5, 0, 0), rightArm=(-35, 0, 40), leftArm=(-35, 0, -40), rightForeArm=(-55, 0, 0), leftForeArm=(-55, 0, 0), rightLeg=(-22, 0, 5), leftLeg=(12, 0, -5), rightShin=(40, 0, 0), leftShin=(20, 0, 0))),
    ]),
    "hurt_left": (.5, [
        (0, pose()),
        (.10, pose(body=(-12, 18, 12), head=(8, -12, 8), rightArm=(-25, 0, 18), leftArm=(-40, 0, -25), rightForeArm=(-65, 0, 0), leftForeArm=(-90, 0, 0), rightLeg=(15, 0, 0), leftLeg=(-15, 0, 0), root_pos=(0, -.5, .6))),
        (.27, pose(body=(-5, 8, 5), rightArm=(-10, 0, 10), leftArm=(-20, 0, -12), rightForeArm=(-45, 0, 0), leftForeArm=(-60, 0, 0))),
        (.5, pose()),
    ]),
    "hurt_right": (.5, [
        (0, pose()),
        (.10, pose(body=(-12, -18, -12), head=(8, 12, -8), leftArm=(-25, 0, -18), rightArm=(-40, 0, 25), leftForeArm=(-65, 0, 0), rightForeArm=(-90, 0, 0), leftLeg=(15, 0, 0), rightLeg=(-15, 0, 0), root_pos=(0, -.5, .6))),
        (.27, pose(body=(-5, -8, -5), leftArm=(-10, 0, -10), rightArm=(-20, 0, 12), leftForeArm=(-45, 0, 0), rightForeArm=(-60, 0, 0))),
        (.5, pose()),
    ]),
    "knockdown": (2.6, [
        (0, pose()),
        (.17, pose(root=(-20, 0, 5), body=(-15, 0, 0), rightArm=(-35, 0, 35), leftArm=(-35, 0, -35), rightForeArm=(-45, 0, 0), leftForeArm=(-45, 0, 0), rightLeg=(-15, 0, 0), leftLeg=(-25, 0, 0))),
        (.5, pose(root=(-88, 0, 0), root_pos=(0, 3.3, 0), rightArm=(10, 0, 35), leftArm=(10, 0, -35), rightForeArm=(-10, 0, 0), leftForeArm=(-10, 0, 0), rightLeg=(-8, 0, 8), leftLeg=(-5, 0, -8), rightShin=(15, 0, 0), leftShin=(10, 0, 0))),
        (1.1, pose(root=(-88, 0, 0), root_pos=(0, 3.3, 0), rightArm=(10, 0, 30), leftArm=(10, 0, -30), rightForeArm=(-15, 0, 0), leftForeArm=(-15, 0, 0), rightLeg=(-8, 0, 8), leftLeg=(-5, 0, -8), rightShin=(15, 0, 0), leftShin=(10, 0, 0))),
        (1.5, pose(root=(-66, 0, 0), root_pos=(0, 2.6, 0), body=(30, 0, 0), head=(18, 0, 0), rightArm=(15, 0, 30), leftArm=(15, 0, -30), rightForeArm=(-50, 0, 0), leftForeArm=(-50, 0, 0), rightLeg=(-55, 0, 0), leftLeg=(-30, 0, 0), rightShin=(85, 0, 0), leftShin=(55, 0, 0))),
        (1.9, pose(root=(-28, 0, 0), root_pos=(0, -2, 0), body=(35, 0, 0), rightArm=(-30, 0, 20), leftArm=(-45, 0, -20), rightForeArm=(-45, 0, 0), leftForeArm=(-60, 0, 0), rightLeg=(-65, 0, 0), leftLeg=(-40, 0, 0), rightShin=(110, 0, 0), leftShin=(70, 0, 0))),
        (2.3, pose(body=(20, 0, 0), root_pos=(0, -1, 0), rightLeg=(-20, 0, 0), leftLeg=(-15, 0, 0), rightShin=(35, 0, 0), leftShin=(25, 0, 0), rightArm=(-15, 0, 10), leftArm=(-15, 0, -10), rightForeArm=(-25, 0, 0), leftForeArm=(-25, 0, 0))),
        (2.6, pose()),
    ]),
    "release": (.1, [(0, pose()), (.1, pose())]),
}


def material(name, color, roughness=.6):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = roughness
    return m


def mesh_box(name, origin, size, bone, mat, rig):
    center = BASIS @ (Vector(origin) + Vector(size) / 2) / 16
    bpy.ops.mesh.primitive_cube_add(size=1, location=center)
    ob = bpy.context.object
    ob.name = name
    ob.scale = (size[0] / 16, size[2] / 16, size[1] / 16)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    ob.data.materials.append(mat)
    group = ob.vertex_groups.new(name=bone)
    group.add(list(range(len(ob.data.vertices))), 1, "REPLACE")
    mod = ob.modifiers.new("Rigid block skinning", "ARMATURE")
    mod.object = rig
    ob.parent = rig
    bevel = ob.modifiers.new("Preview bevel only (not exported)", "BEVEL")
    bevel.width = .008
    bevel.segments = 2
    return ob


def author():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for a in list(bpy.data.actions):
        bpy.data.actions.remove(a)
    bpy.ops.object.armature_add()
    rig = bpy.context.object
    rig.name = "BendsDaffo_Rig"
    rig.data.name = "BendsDaffo_Skeleton"
    rig.show_in_front = True
    bpy.ops.object.mode_set(mode="EDIT")
    rig.data.edit_bones.remove(rig.data.edit_bones[0])
    for name, (parent, pivot) in BONES.items():
        b = rig.data.edit_bones.new(name)
        b.head = BASIS @ Vector(pivot) / 16
        # Identity rest axes are essential for lossless local export.
        b.tail = b.head + Vector((0, .18, 0))
        if parent:
            b.parent = rig.data.edit_bones[parent]
    bpy.ops.object.mode_set(mode="OBJECT")
    rig.animation_data_create()
    for name, (duration, keys) in CLIPS.items():
        action = bpy.data.actions.new("BD_" + name)
        action.use_fake_user = True
        action["bd_duration"] = duration
        names = [] if name == "release" else list(BONES)
        action["bd_bones"] = json.dumps(names)
        rig.animation_data.action = action
        for time, values in keys:
            for bone_name in BONES:
                b = rig.pose.bones[bone_name]
                b.rotation_mode = "XYZ"
                r = values.get(bone_name, (0, 0, 0))
                physical = (-r[0], r[1], -r[2])
                rotation = BASIS @ Euler(tuple(math.radians(v) for v in physical), "XYZ").to_matrix() @ INVERSE
                b.rotation_euler = rotation.to_euler("XYZ")
                b.location = BASIS @ Vector(values.get(bone_name + "_pos", (0, 0, 0))) / 16
                frame = round(time * 30) + 1
                b.keyframe_insert("rotation_euler", frame=frame, group=bone_name)
                b.keyframe_insert("location", frame=frame, group=bone_name)
        for fc in action.fcurves:
            for point in fc.keyframe_points:
                point.interpolation = "BEZIER"
                point.handle_left_type = "AUTO_CLAMPED"
                point.handle_right_type = "AUTO_CLAMPED"
    # Small additive first-person arm overlays, retaining vanilla camera,
    # item handling, map poses and render conventions.
    for name in ["punch_right", "punch_left", "strike", "chop", "mine", "hurt_left", "hurt_right"]:
        duration = CLIPS[name][0]
        action = bpy.data.actions.new("BD_fp_" + name)
        action.use_fake_user = True
        action["bd_duration"] = duration
        action["bd_bones"] = json.dumps(["rightArm", "rightForeArm"])
        rig.animation_data.action = action
        impact = -18 if name.startswith("hurt") else -32
        for fraction, rx, elbow in [(0, 0, 0), (.22, 12, -20), (.43, impact, -8), (.68, -8, -12), (1, 0, 0)]:
            for b in rig.pose.bones:
                b.location = (0, 0, 0)
                b.rotation_euler = (0, 0, 0)
            for bone_name, angle in [("rightArm", rx), ("rightForeArm", elbow)]:
                b = rig.pose.bones[bone_name]
                b.rotation_euler = (BASIS @ Euler((math.radians(-angle), 0, 0)).to_matrix() @ INVERSE).to_euler("XYZ")
                b.keyframe_insert("rotation_euler", frame=round(fraction * duration * 30) + 1, group=bone_name)
                b.keyframe_insert("location", frame=round(fraction * duration * 30) + 1, group=bone_name)
            for fc in action.fcurves:
                for point in fc.keyframe_points:
                    point.handle_left_type = "AUTO_CLAMPED"
                    point.handle_right_type = "AUTO_CLAMPED"
    skin = material("Warm skin", (.64, .35, .20))
    shirt = material("Daffo teal", (.025, .49, .45))
    pants = material("Midnight trousers", (.025, .05, .10))
    hair = material("Hair", (.07, .035, .018))
    for name, origin, size, bone, mat in [
        ("Torso", (-4, 12, -2), (8, 12, 4), "body", shirt),
        ("Head", (-4, 24, -4), (8, 8, 8), "head", skin),
        ("Hair", (-4.1, 30, -4.1), (8.2, 2.2, 8.2), "head", hair),
        ("Right upper arm", (-8, 18, -2), (4, 6, 4), "rightArm", shirt),
        ("Right forearm", (-8, 12, -2), (4, 6, 4), "rightForeArm", skin),
        ("Left upper arm", (4, 18, -2), (4, 6, 4), "leftArm", shirt),
        ("Left forearm", (4, 12, -2), (4, 6, 4), "leftForeArm", skin),
        ("Right thigh", (-3.9, 6, -2), (4, 6, 4), "rightLeg", pants),
        ("Right shin", (-3.9, 0, -2), (4, 6, 4), "rightShin", pants),
        ("Left thigh", (-.1, 6, -2), (4, 6, 4), "leftLeg", pants),
        ("Left shin", (-.1, 0, -2), (4, 6, 4), "leftShin", pants),
    ]:
        mesh_box(name, origin, size, bone, mat, rig)
    bpy.ops.mesh.primitive_plane_add(size=200)
    bpy.context.object.name = "Preview floor — not exported"
    bpy.context.object.data.materials.append(material("Floor", (.018, .03, .045)))
    bpy.ops.object.camera_add(location=(3.7, 5.6, 3.0))
    camera = bpy.context.object
    camera.name = "Preview camera"
    camera.rotation_euler = (Vector((0, .3, .9)) - camera.location).to_track_quat("-Z", "Y").to_euler()
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 3.5
    bpy.context.scene.camera = camera
    for name, location, energy, size in [
        ("Key", (2, 3, 5), 850, 4),
        ("Fill", (-3, 1, 2), 500, 3),
        ("Rim", (0, -3, 4), 1000, 3),
    ]:
        bpy.ops.object.light_add(type="AREA", location=location)
        light = bpy.context.object
        light.name = name
        light.data.energy = energy
        light.data.shape = "DISK"
        light.data.size = size
        light.rotation_euler = (Vector((0, 0, 1)) - light.location).to_track_quat("-Z", "Y").to_euler()
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.render.resolution_x = 900
    scene.render.resolution_y = 700
    scene.render.resolution_percentage = 100
    scene.world.color = (.08, .08, .08)
    scene.view_settings.view_transform = "AgX"
    scene.render.fps = 30
    scene.frame_start = 1
    scene.frame_end = 16
    rig.animation_data.action = bpy.data.actions["BD_punch_right"]
    scene.frame_set(7)
    bpy.ops.object.select_all(action="DESELECT")
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    rig["README"] = "Select BD_ actions in Action Editor; duration seconds and bone list are action properties. Export with tools/export_blender.py. Blender previews are not in-game screenshots."
    ROOT.joinpath("blender").mkdir(exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT / "blender/Bends-Daffo.blend"))
    export(ROOT)
    if "--render" in sys.argv:
        for clip, frame in [("punch_right", 7), ("knockdown", 25), ("chop", 9), ("swim", 12), ("jump", 5), ("run", 5)]:
            rig.animation_data.action = bpy.data.actions["BD_" + clip]
            scene.frame_set(frame)
            scene.render.filepath = str(ROOT / f"blender/preview-{clip}.png")
            bpy.ops.render.render(write_still=True)


if __name__ == "__main__":
    author()
