# Memasang Bends-Daffo

Target paket ini Minecraft **Bedrock 26.50**, bukan Java Edition.
Uji dahulu di salinan dunia atau dunia baru. Import dan rendering dalam game
belum diverifikasi dari lingkungan pengembangan ini.

## Android, Windows, dan iPhone/iPad

1. Unduh `Bends-Daffo-1.0.0-Bedrock-26.50.mcaddon`.
2. Buka file memakai Minecraft. Pada Android/iOS, gunakan file manager atau
   menu berbagi → Minecraft. Pada Windows, buka file dengan Minecraft.
   Tunggu notifikasi impor kedua pack.
3. Buka edit/create world → **Behavior Packs** → aktifkan **Bends-Daffo • Runtime**.
4. Pada **Resource Packs**, pastikan **Bends-Daffo • Animations** juga aktif.
   Posisikan di atas pack animasi lain atau nonaktifkan pack yang bentrok.
5. Pilih resource pack aktif → ikon **roda gigi** → pilih **Sendi siku/lutut —
   skin klasik Steve** untuk hasil sendi penuh. Pakai Steve/classic skin dahulu.
   Pilih **Skin kompatibel** bila skin Alex/slim, Persona, atau Marketplace
   tidak tampil sesuai. Mode ini mempertahankan sendi bawaan.
6. Tidak perlu menyalakan Beta APIs/eksperimen untuk API stabil yang dipakai.
   Buka dunia dan pilih kamera **orang ketiga** agar gerak tubuh terlihat.
7. Jalankan checklist `UJI_DALAM_GAME.md`. Bila script gagal, buka content log
   melalui pengaturan Creator dan catat error persisnya.

Jika file berubah menjadi `.mcaddon.zip` saat unduh, kembalikan ekstensi ke
`.mcaddon`. Jangan mengekstrak bundle sebelum mencoba import normal.
Nama pack muncul dua karena behavior dan resource pack mempunyai fungsi
berbeda; keduanya diperlukan.

## Bermain bersama teman

Host memasang dan mengaktifkan kedua pack pada **dunia yang dibagikan**.
Aktifkan opsi agar peserta wajib menerima resource pack; setiap teman harus
menerima unduhan pack saat bergabung. Mereka tidak cukup mengaktifkan pack
hanya pada dunia pribadi masing-masing.

Untuk reaksi dipukul antar pemain, aktifkan PvP/friendly fire pada dunia.
Jika PvP dimatikan, server tidak memberikan damage pada teman, sehingga
event hurt tidak terjadi. Uji di Survival pada kedua pemain.

Pada dedicated server, letakkan `.mcpack` yang sudah diekstrak di direktori
`behavior_packs` dan `resource_packs`, kemudian daftarkan UUID/header version
dari masing-masing `manifest.json` di `world_behavior_packs.json` dan
`world_resource_packs.json` dunia server. Atur `texturepack-required=true`
jika ingin semua pemain memakai resource pack. Restart server setelah
mengubah paket dunia. Konfigurasi server nyata belum diuji pada proyek ini.

Konsol biasanya memerlukan dunia/server/Realm yang telah memasang add-on
melalui platform yang mendukung import; alur import file lokal berbeda dan
tidak diverifikasi di sini.

## Memeriksa atau mengubah peluang jatuh

Perintah di bawah opsional dan membutuhkan cheats/izin operator:

```text
/scriptevent bends_daffo:status
/scriptevent bends_daffo:demo knockdown
/scriptevent bends_daffo:chance 1
```

`demo knockdown` memainkan urutan jatuh/bangkit pada pengirim tanpa damage.
`chance 1` memudahkan pengujian jatuh saat melee di tanah; cooldown tetap
5 detik. Setelah uji, pulihkan nilai default:

```text
/scriptevent bends_daffo:chance 0.22
```

Jatuh tidak mengubah hitbox atau input. Pose dapat tampak bergeser jika aktor
bergerak, dan dapat beririsan dengan dinding/terrain karena bukan ragdoll
bertabrakan dengan lingkungan.
