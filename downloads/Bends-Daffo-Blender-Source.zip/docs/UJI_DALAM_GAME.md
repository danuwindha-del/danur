# Bukti validasi dan checklist Minecraft

## Sudah dilakukan di lingkungan pengembangan

| Pemeriksaan | Hasil |
| --- | --- |
| Blender | 4.3.2, rig editable dan 24 Actions diekspor |
| Tipe Script API 2.10.0 | Lulus `npm run typecheck` |
| Tes logika host/mock | 16 lulus, 0 gagal, 0 dilewati |
| Data pack | JSON, manifest/dependency, UUID, entrypoint, bone hierarchy, UV dan referensi lulus |
| Ekspor Blender | 5.606 bone-frame sesuai evaluasi rig; toleransi `1e-5` |
| Preview | Pukul, chop, jump, swim, knockdown, run dirender memakai Blender CPU |

Pemeriksaan ini tidak menjalankan engine Minecraft. Status berikut **BELUM
DIUJI**: impor oleh game, content log game, renderer Bedrock, third/first
person, variasi skin, armor, AI saat animasi, penampilan bagi peserta baru,
multiplayer dua client, Android/iOS/Windows, dedicated server/Realm, serta
FPS/TPS dunia dengan banyak pemain. Tidak ada klaim telah lulus untuk tes itu.

## Checklist penerimaan di Bedrock 26.50

Gunakan dunia baru flat, kedua pack aktif, mode sendi aktif, skin klasik
Steve, kamera orang ketiga dan tanpa resource pack animasi lain.

1. **Import dan content log:** kedua pack berhasil diimpor. Masuk dunia;
   content log tidak memuat error manifest, script module, controller,
   animation, query Molang, ataupun geometry Bends-Daffo. Jika error muncul,
   simpan pesan dan hentikan klaim kompatibilitas sebelum koreksi.
2. **Pukul:** ayunkan tangan kosong beberapa kali, lalu pukul zombie.
   Terlihat jab kanan/kiri bergantian dan torso ikut bergerak. Coba sword/axe:
   gerakan berubah ke strike tanpa mengubah damage dasar Minecraft.
3. **Chop:** di Survival, tahan penambangan oak log memakai axe; gerakan
   chop berulang sepanjang proses. Batalkan sebelum blok pecah lalu lepaskan
   input: tidak ada chop berulang selanjutnya. Ulangi crimson/warped stem.
   Memakai tangan kosong dan menambang stone harus memakai mine.
4. **Lompat:** naik dari tanah, jatuh dari tepi platform, dan mendarat.
   Takeoff, fall, serta land terlihat berbeda; berjalan keluar dari tepi
   tidak dianggap takeoff. Lanjut berlari setelah land selesai.
5. **Air:** berenang sprint, lalu mengapung tanpa sprint. Swim dan tread-water
   berbeda; kembali ke jalan saat keluar dari air. Periksa posisi model
   terhadap permukaan air dan tidak terbalik.
6. **Reaksi mob:** pukul zombie, husk dan drowned dewasa pada tanah datar.
   Reaksi terlihat pada mob yang terkena damage; anak zombie dan hewan
   mempertahankan animasi vanilla. Damage fire/fall/projectile tidak
   dianggap pukulan melee.
7. **Jatuh/bangkit:** gunakan `/scriptevent bends_daffo:chance 1`, pukul aktor
   hidup di tanah, kemudian tunggu 2,6 detik. Urutan jatuh → rebah → bangkit
   selesai dan pose kembali normal. Pukulan berikutnya dalam 5 detik tidak
   memulai jatuh baru. Pastikan tidak ada damage atau stun tambahan.
8. **Multiplayer/PvP:** dua client 26.50, keduanya mengunduh RP dunia. Pada
   Survival dengan friendly fire aktif, A memukul B dan sebaliknya. Masing-
   masing melihat animasi penyerang dan penerima. Ulangi sambil C mengamati
   keduanya. Uji join ulang ketika aktor bergerak atau sedang bereaksi.
9. **Kamera pertama:** pukul, chop, mine dan flinch masih memperlihatkan
   lengan/item tanpa tubuh menutupi kamera. Peta, shield, spear, bow dan
   crossbow masih dapat dipakai. Jika bermasalah, simpan contoh item/skin.
10. **Pose khusus:** naik boat, elytra, creative flight, spectator, tidur,
    sneak, memanjat dan memakai item. Locomotion kustom dilepas, pose
    bawaan kembali dan tidak macet setelah berhenti melakukan aksi.
11. **Skin/armor:** uji Steve, custom classic 64×64, Alex/slim dan Persona.
    Periksa kedua mode subpack, armor dan item terpasang. Mode kompatibel
    memang tidak memberikan joint tambahan; jangan menilai itu sebagai
    elbow/knee yang telah bekerja. Catat irisan armor pada mode sendi aktif.
12. **Durasi bermain:** uji 10–15 menit bersama beberapa pemain dengan
    zombie aktif, disconnect/reconnect dan pergantian dimensi. Periksa
    content log, FPS/TPS, script watchdog dan animasi yang tertinggal.

Pulihkan `/scriptevent bends_daffo:chance 0.22` setelah pengujian. Untuk
bug report, sertakan versi lengkap Minecraft, perangkat, mode subpack,
skin, pack lain yang aktif, langkah reproduksi dan pesan content log.
